from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    ld = LaunchDescription()

    # imu_data_node = Node(
    #     package="ml3_ros2",
    #     executable="imu_data_v1"
    # )

    # imu_sub_node = Node(
    #     package="ml3_ros2",
    #     executable="imu_sub"
    # )

    # ir_data_node = Node(
    #     package="ml3_ros2",
    #     executable="ir_read_data"
    # )

    # ir_sub_node = Node(
    #     package="ml3_ros2",
    #     executable="ir_data_sub"
    # )

    # qr_data_node = Node(
    #     package="ml3_ros2",
    #     executable="qr_data"
    # )

    # qr_sub_node = Node(
    #     package="ml3_ros2",
    #     executable="qr_sub"
    # )

    traffic_light_node = Node(
        package= "ml3_ros2",
        executable= "traffic_light"
    )

    traffic_sub_node = Node(
        package= "ml3_ros2",
        executable= "traffic_sub"
    )

    # ultra_data_node = Node(
    #     package="ml3_ros2",
    #     executable="ultra_data"
    # )

    # ultra_sub_node = Node(
    #     package="ml3_ros2",
    #     executable="ultra_sub"
    # )
#     cam_follow_node = Node(
#          package="ml3_ros2",
#          executable="cam_follow"
#      )
    
#     motor_cam_follow_node = Node(
#          package="mbedros2",
#          executable="mbed_motor_ctrl"
#     )
    # sendcommandkey_node = Node(
    #      package="ml3_ros2",
    #      executable="sendcommandkey"
    # )

    # sendcommandkey_node = Node(
    #     package = "ml3_ros2",
    #     executable="sendcommandkey"
    # )
    
#     ld.add_action(sendcommandkey_node)
# #     ld.add_action(motor_cam_follow_node)
    # ld.add_action(sendcommandkey_node)
    # ld.add_action(imu_data_node)
    # ld.add_action(imu_sub_node)
    # ld.add_action(ir_data_node)
    # ld.add_action(ir_sub_node)
    # ld.add_action(qr_data_node)
    # ld.add_action(qr_sub_node)
    ld.add_action(traffic_light_node)
    ld.add_action(traffic_sub_node)
    # ld.add_action(ultra_data_node)
    # ld.add_action(ultra_sub_node)

    return ld